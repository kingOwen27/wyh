class ValidationError(ValueError):
    pass